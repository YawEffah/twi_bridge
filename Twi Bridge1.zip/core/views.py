import os
import json
import requests
from django.shortcuts import render
from django.http import JsonResponse
from .models import TranslationHistory

def index(request):
    input_text = ""
    translated_text = ""
    direction = "en-tw"
    
    if request.method == 'POST':
        input_text = request.POST.get('text', '')
        direction = request.POST.get('direction', 'en-tw')
        
        if input_text:
            try:
                api_key = os.environ.get('GHANA_NLP_API_KEY')
                if not api_key:
                    raise Exception("Translation API key is missing. Please configure your .env file.")

                url = "https://translation-api.ghananlp.org/v1/translate"
                headers = {
                    'Content-Type': 'application/json',
                    'Ocp-Apim-Subscription-Key': api_key,
                }
                payload = {"in": input_text, "lang": direction}
                
                response = requests.post(url, headers=headers, json=payload, timeout=10)
                response.raise_for_status()
                
                try:
                    res_data = response.json()
                    translated_text = res_data.get('out', str(res_data))
                except (ValueError, AttributeError):
                    translated_text = response.text.strip(' \n"')

                if request.user.is_authenticated:
                    TranslationHistory.objects.create(
                        user=request.user,
                        source_text=input_text,
                        translated_text=translated_text,
                        direction=direction
                    )
            except Exception as e:
                from django.contrib import messages
                messages.error(request, f"Translation failed: {str(e)}")

    db_history = []
    if request.user.is_authenticated:
        db_history = TranslationHistory.objects.filter(user=request.user).order_by('-created_at')[:50]
        
    context = {
        'db_history': db_history,
        'input_text': input_text,
        'translated_text': translated_text,
        'direction': direction,
    }
    return render(request, 'core/index.html', context)

def translate_api(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)
    
    try:
        data = json.loads(request.body)
        text = data.get('text', '')
        direction = data.get('direction', 'en-tw')
        
        if not text:
            return JsonResponse({'error': 'No text provided'}, status=400)

        api_key = os.environ.get('GHANA_NLP_API_KEY')
        url = "https://translation-api.ghananlp.org/v1/translate"
        headers = {
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache',
            'Ocp-Apim-Subscription-Key': api_key,
        }
        payload = {
            "in": text,
            "lang": direction
        }

        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        try:
            translated_text = response.json()
        except ValueError:
            translated_text = response.text.strip(' \n"')
            
        if isinstance(translated_text, dict):
            # Sometimes APIs return {"out": "Translated text"}
            # adjust if required
            translated_text = translated_text.get('out', str(translated_text))

        if request.user.is_authenticated:
            TranslationHistory.objects.create(
                user=request.user,
                source_text=text,
                translated_text=translated_text,
                direction=direction
            )

        return JsonResponse({'result': translated_text})

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
